/*
 * File Name:        general.js
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

// alert("general.js");









// No import jQuery yet!   .::::::::::::
// "use strict";
// (function ($) { })(jQuery);