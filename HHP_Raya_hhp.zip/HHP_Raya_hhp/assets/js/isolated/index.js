/*
 * File Name:        index.js
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

// dev area 1404/04/19
const sections = document.querySelectorAll("section");
const navLi = document.querySelectorAll("nav .container ul li");
window.onscroll = () => {
  var current = "";

  sections.forEach((section) => {
    const sectionTop = section.offsetTop;
    if (pageYOffset >= sectionTop - 100) {
      current = section.getAttribute("id"); }
  });

  navLi.forEach((li) => {
    li.classList.remove("active");
    if (li.classList.contains(current)) {
      li.classList.add("active");
      console.log(li);
    }
  });
};
// End dev area 1404/04/19




particlesJS('particles-js', {
    "particles": {
        "number": {
            "value": 160,
            "density": {
                "enable": true,
                "value_area": 800
            }
        },
        "color": {
            "value": "random"
        },
        "shape": {
            "type": "circle",
            "stroke": {
                "width": 0,
                "color": "#000000"
            },
            "polygon": {
                "nb_sides": 5
            },
            "image": {
                "src": "img/github.svg",
                "width": 100,
                "height": 100
            }
        },
        "opacity": {
            "value": 1,
            "random": true,
            "anim": {
                "enable": true,
                "speed": 1,
                "opacity_min": 0,
                "sync": false
            }
        },
        "size": {
            "value": 3,
            "random": true,
            "anim": {
                "enable": false,
                "speed": 4,
                "size_min": 0.3,
                "sync": false
            }
        },
        "line_linked": {
            "enable": false,
            "distance": 150,
            "color": "#ffffff",
            "opacity": 0.4,
            "width": 1
        },
        "move": {
            "enable": true,
            "speed": 1,
            // "direction": "none",
            "direction": "top",
            "random": true,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
                "enable": false,
                "rotateX": 600,
                "rotateY": 600
            }
        }
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": {
            "onhover": {
                "enable": false,
                "mode": "bubble"
            },
            "onclick": {
                "enable": true,
                "mode": "repulse"
            },
            "resize": true
        },
        "modes": {
            "grab": {
                "distance": 400,
                "line_linked": {
                    "opacity": 1
                }
            },
            "bubble": {
                "distance": 250,
                "size": 0,
                "duration": 2,
                "opacity": 0,
                "speed": 3
            },
            "repulse": {
                "distance": 400,
                "duration": 0.4
            },
            "push": {
                "particles_nb": 4
            },
            "remove": {
                "particles_nb": 2
            }
        }
    },
    "retina_detect": true
}

);

// No import jQuery yet!   .::::::::::::
// "use strict";
// (function ($) {
//     alert('jQuery');
// })(jQuery);

// /////////////////////// Swiper Slider /////////////////////// //
const progressCircle_barchasb_asm = document.querySelector(".barchasb_asm_Swiper .autoplay-progress svg");
const progressContent_barchasb_asm = document.querySelector(".barchasb_asm_Swiper .autoplay-progress span");
var barchasb_asm_swiper = new Swiper(".barchasb_asm_Swiper", {
    lazy: true,
    loop: true,
    effect: "coverflow",
    autoplay: {
        delay: 5000,
    },
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: "auto",
    coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows: true,
    },
    pagination: {
        el: ".swiper-pagination",
        // dynamicBullets: true,
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    on: {
        autoplayTimeLeft(s, time, progress) {
          progressCircle_barchasb_asm.style.setProperty("--progress", 1 - progress);
          progressContent_barchasb_asm.textContent = `${Math.ceil(time / 1000)}s`;
        }
    },
});

const progressCircle_atiket = document.querySelector("div.swiper.atiket .autoplay-progress svg");
const progressContent_atiket = document.querySelector("div.swiper.atiket .autoplay-progress span");
var atiket_swiper = new Swiper(".atiket", {
    lazy: true,
    loop: true,
    autoplay: {
        delay: 5000,
    },
    grabCursor: true,
    centeredSlides: true,
    
    // slidesPerView: "auto",
    slidesPerView: 1,
    // effect: "fade",
    effect: "flip",
    
    
    // coverflowEffect: {
    //     rotate: 50,
    //     stretch: 0,
    //     depth: 100,
    //     modifier: 1,
    //     slideShadows: true,
    // },
    pagination: {
        el: ".swiper-pagination",
        // dynamicBullets: true,
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    on: {
        autoplayTimeLeft(s, time, progress) {
          progressCircle_atiket.style.setProperty("--progress", 1 - progress);
          progressContent_atiket.textContent = `${Math.ceil(time / 1000)}s`;
        }
    },
});

const progressCircle_barnameh_haftegi = document.querySelector("#barnameh_haftegi_slider .autoplay-progress svg");
const progressContent_barnameh_haftegi = document.querySelector("#barnameh_haftegi_slider .autoplay-progress span");
var barnameh_haftegi_swiper = new Swiper(".thumbsSlider", {
    lazy: true,
    loop: true,
    grabCursor: true,

    spaceBetween: 0,
    slidesPerView: 6,
    freeMode: true,
    watchSlidesProgress: true,
    
});
var barnameh_haftegi_swiper2 = new Swiper(".largeSlide", {
    lazy: true,
    // zoom: true,
    grabCursor: true,
    centeredSlides: true,
    autoplay: {
        delay: 5000,
    },
    loop: true,
    spaceBetween: 0,
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    thumbs: {
        swiper: barnameh_haftegi_swiper,
    },
    on: {
        autoplayTimeLeft(s, time, progress) {
          progressCircle_barnameh_haftegi.style.setProperty("--progress", 1 - progress);
          progressContent_barnameh_haftegi.textContent = `${Math.ceil(time / 1000)}s`;
        }
    },
});



// 
// TEST
// 

document.addEventListener('DOMContentLoaded', () => {
  const lightbox = document.getElementById('lightbox');
  const lightboxWrapper = document.querySelector('.lightbox-swiper .swiper-wrapper');
  const lightboxClose = document.getElementById('lightbox-close');
  let lightboxSwiper;

  const images = document.querySelectorAll('.largeSlide .swiper-slide img');

  // ساخت اسلایدها فقط یکبار
  images.forEach((slideImg) => {
    const slide = document.createElement('div');
    slide.classList.add('swiper-slide');
    const image = slideImg.cloneNode(true);
    image.style.width = '90%';
    image.style.objectFit = 'contain';
    slide.appendChild(image);
    lightboxWrapper.appendChild(slide);
  });

  images.forEach((img, index) => {
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => {
      if (lightboxSwiper) {
        lightboxSwiper.destroy(true, true);
        lightboxSwiper = null;
      }

      lightboxSwiper = new Swiper('.lightbox-swiper', {
        initialSlide: index,
        loop: images.length > 1,
        slidesPerView: 1,
        spaceBetween: 10,
        navigation: {
          nextEl: '.lightbox-swiper .swiper-button-next',
          prevEl: '.lightbox-swiper .swiper-button-prev',
        },
        pagination: {
          el: '.lightbox-swiper .swiper-pagination',
          type: 'bullets',
          clickable: true,
        },
        simulateTouch: true,
        touchRatio: 1,
        touchAngle: 45,
      });

      lightbox.classList.add('open');
      document.body.style.overflow = 'hidden';
    });
  });

  lightboxClose.addEventListener('click', () => {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
    if (lightboxSwiper) {
      lightboxSwiper.destroy(true, true);
      lightboxSwiper = null;
    }
  });

  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) {
      lightbox.classList.remove('open');
      document.body.style.overflow = '';
      if (lightboxSwiper) {
        lightboxSwiper.destroy(true, true);
        lightboxSwiper = null;
      }
    }
  });

  // بستن با کلید Esc (اختیاری)
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && lightbox.classList.contains('open')) {
      lightbox.classList.remove('open');
      document.body.style.overflow = '';
      if (lightboxSwiper) {
        lightboxSwiper.destroy(true, true);
        lightboxSwiper = null;
      }
    }
  });
});



// // راه‌اندازی اسلایدر اصلی
// // const mainSwiper = new Swiper('.largeSlide', {
// //   loop: true,
// //   centeredSlides: true,
// //   pagination: {
// //     el: '.largeSlide .swiper-pagination',
// //     clickable: true,
// //   },
// //   navigation: {
// //     nextEl: '.largeSlide .swiper-button-next',
// //     prevEl: '.largeSlide .swiper-button-prev',
// //   },
// // });

// const lightbox = document.getElementById('lightbox');
// const lightboxWrapper = document.querySelector('.lightbox-swiper .swiper-wrapper');
// const lightboxClose = document.getElementById('lightbox-close');
// let lightboxSwiper;

// // کلیک روی هر تصویر اسلایدر اصلی
// document.querySelectorAll('.largeSlide .swiper-slide img').forEach((img, index) => {
//   img.style.cursor = 'pointer';
//   img.addEventListener('click', () => {
//     // پاک کردن اسلایدهای قبلی لایت‌باکس
//     lightboxWrapper.innerHTML = '';

//     // alert('work');
      
//     // اضافه کردن تمام تصاویر اسلایدر اصلی به لایت‌باکس
//     document.querySelectorAll('.largeSlide .swiper-slide img').forEach((slideImg) => {
//       const slide = document.createElement('div');
//       slide.classList.add('swiper-slide');

//       const image = slideImg.cloneNode(true);
//       image.style.width = '90%';
//     //   image.style.height = '100%';
//       image.style.objectFit = 'contain';

//       slide.appendChild(image);
//       lightboxWrapper.appendChild(slide);
//     });

//     // نابود کردن نمونه قبلی اگر وجود داشت
//     if (lightboxSwiper) lightboxSwiper.destroy(true, true);

//     // راه‌اندازی Swiper لایت‌باکس با شروع از اسلاید کلیک شده
//     lightboxSwiper = new Swiper('.lightbox-swiper', {
//       initialSlide: index,
//       loop: true,
//       slidesPerView: 1,
//       spaceBetween: 10,
//       navigation: {
//         nextEl: '.lightbox-swiper .swiper-button-next',
//         prevEl: '.lightbox-swiper .swiper-button-prev',
//       },
//       pagination: {
//         el: '.lightbox-swiper .swiper-pagination',
//         type: 'bullets',
//         clickable: true,
//       },
//         simulateTouch: true,  // حتما فعال باشد
//         touchRatio: 1,
//         touchAngle: 45,
//     });

//     // نمایش لایت‌باکس و جلوگیری از اسکرول پشت آن
//     lightbox.classList.add('open');
//     document.body.style.overflow = 'hidden';
//   });
// });

// // بستن لایت‌باکس با کلیک روی ×
// lightboxClose.addEventListener('click', () => {
//   lightbox.classList.remove('open');
//   document.body.style.overflow = '';
//   if (lightboxSwiper) lightboxSwiper.destroy(true, true);
// });

// // بستن لایت‌باکس با کلیک روی پس‌زمینه
// lightbox.addEventListener('click', (e) => {
//   if (e.target === lightbox) {
//     lightbox.classList.remove('open');
//     document.body.style.overflow = '';
//     if (lightboxSwiper) lightboxSwiper.destroy(true, true);
//   }
// });

// 
// END TEST
// 





// /////////////////////// Tiny Slider /////////////////////// //

// let hhpSlider = tns({
//     "container": "#barchasb_asm-slider",
//     "items": 1,
//     //   "controlsContainer": "#customize-controls",
//     //   "navContainer": "#customize-thumbnails",
//     "navAsThumbnails": true,
//     "autoplay": true,
//     "autoplayTimeout": 4000,
//     //   "autoplayButton": "#customize-toggle",
//     "swipeAngle": false,
//     "speed": 400
// });

//
// 
// 
// let PARTNERSlider = tns({
//   container: ".PARTNERS-slider",
//   loop: true,
//   autoplay: true,
//   autoplayTimeout:5000,
//   lazyload:true,
//   items: 6,
//   swipeAngle: false,
//   speed: 400,
//   textDirection: "ltr",
//   nav: false,
//   controlsContainer: "#PARTNERSCTRL",
//   prevButton: ".PARTNERSCTRLPrev",
//   nextButton: ".PARTNERSCTRLNext",
//   autoplayButton: ".autoplayDefault-dNone",
//   responsive: {
//     0: {
//       items: 1,
//     },
//     600: {
//       items: 5,
//     },
//   },
//     onInit: function() {
//         let autoplayInterval = setInterval(function() {
//             const activeSlideImage = document.querySelectorAll('#section_3 .tns-slide-active');
//             // console.log(activeSlideImage);
//             activeSlideImage.forEach(line => line.querySelector('img').classList.remove("active"));
//             activeSlideImage[2].querySelector('img').classList.add("active");
            
//             PARTNERSlider.play();
//         }, 500); // Adjust the interval as needed
//     }
// });