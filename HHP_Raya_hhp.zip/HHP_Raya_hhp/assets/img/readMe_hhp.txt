وب برای کاهش حجم عکس:
https://squoosh.app/

وب برای کاهش اندازه:
https://imageresizer.com/