<?php
/*
* File Name:        footer.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
get_template_part('template-parts/footer/general');
wp_footer();
?>
</body>

</html>