<?php
/*
Template Name:      second-page
* File Name:        temp_second_page.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// echo"second-page";

// Header
get_header();

// Path Template Parts:
$path = "template-parts/index";

// Template Parts:
// get_template_part("$path/company-profile"); // <---- DELETE THIS
get_template_part( "$path/first_baner" );



// footer
get_footer();