<?php
/*
* File Name:        index.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// echo"index.php is HERE ...";

// Header
get_header();

// Path Template Parts:
$path = "template-parts/index";

// Template Parts:
get_template_part( "template-parts/general/nav" );
get_template_part( "$path/first_baner" );
get_template_part( "$path/our_products" );
get_template_part( "$path/barchasb_asm" );
get_template_part( "$path/atiket" );
get_template_part( "$path/barnameh_haftegi" );
get_template_part( "$path/shoaar_1" );
get_template_part( "$path/ordering_steps" );
get_template_part( "$path/shoaar_2" );
get_template_part( "$path/contact_us" );
get_template_part( "$path/our_honors" );
get_template_part( "$path/about_us" );

get_template_part( "$path/comments_index" );
get_template_part( "template-parts/general/footer" );



// footer
get_footer();