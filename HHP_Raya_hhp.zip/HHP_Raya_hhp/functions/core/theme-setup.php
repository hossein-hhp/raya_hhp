<?php
/*
* File Name:        theme-setup.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// VenusITC Setup Theme
function theme_setup()
{
    // title-tag
    add_theme_support('title-tag');

    // Add theme support for Featured Images
    add_theme_support('post-thumbnails');

    // Add theme support for selective refresh for widgets.
    add_theme_support('customize-selective-refresh-widgets');
    // Add theme support for post format
    add_theme_support(
        'post-formats',
        array(
            'aside',
            'audio',
            'image',
            'gallery',
            'link',
            'quote',
            'status',
            'video'
        )
    );

    // Add theme support for HTML5 Semantic Markup
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'script',
            'style',
        )
    );
}
add_action('after_setup_theme', 'theme_setup');
