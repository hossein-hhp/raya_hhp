<?php
/*
 * File Name:        theme-enqueue-scripts.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Include General CSS & JS libraries
function RAYA_HHP_enqueue_scripts()
{
    // Include CSS libraries:   .::::::::::::

    if (is_front_page()) {
        // CSS: Bootstrap
        wp_register_style('Bootstrap', RAYA_HHP_THEME_URI . 'assets/tmp/bootstrap.min.css', array(), '5.3.3');
        wp_enqueue_style('Bootstrap');

        // CSS: fonts
        wp_register_style('LTRWebfonts', RAYA_HHP_THEME_URI . 'assets/css/fonts.css', array(), RAYA_HHP_THEME_VERSION);
        wp_enqueue_style('LTRWebfonts');
    }

    // CSS: General
    wp_register_style('generalStyle', RAYA_HHP_THEME_URI . 'assets/css/general.css', array(), RAYA_HHP_THEME_VERSION);
    wp_enqueue_style('generalStyle');
    // CSS: General-Responsive
    wp_register_style('generalResponsive', RAYA_HHP_THEME_URI . 'assets/css/general-responsive.css', array(), RAYA_HHP_THEME_VERSION);
    wp_enqueue_style('generalResponsive');

    // CSS: Swiper_Slider_css
    wp_register_style('Swiper_Slider_css', RAYA_HHP_THEME_URI . '/assets/css/lib/swiper-bundle.min.css', array(), '11.2.6');
    wp_enqueue_style('Swiper_Slider_css');

    // CSS: index page
    if (is_front_page()) {
        wp_register_style('indexStyle', RAYA_HHP_THEME_URI . 'assets/css/isolated/index.css', array(), RAYA_HHP_THEME_VERSION);
        wp_enqueue_style('indexStyle');
        wp_register_style('indexResponsive', RAYA_HHP_THEME_URI . 'assets/css/isolated/index-responsive.css', array(), RAYA_HHP_THEME_VERSION);
        wp_enqueue_style('indexResponsive');
    }


    // Include JS libraries:   .::::::::::::

    // JS: jquery (Add from: /wp-includes/js/jquery/jquery.min.js)
    // wp_enqueue_script("jquery");

    // JS: Swiper_Slider
    wp_register_script('Swiper_Slider_js', RAYA_HHP_THEME_URI . '/assets/js/lib/swiper-bundle.min.js', array(), '11.2.6', true);
    wp_enqueue_script('Swiper_Slider_js');

    // JS: particles
    wp_register_script('particles', RAYA_HHP_THEME_URI . '/assets/js/lib/particles.min.js', array(), '2.0.0', true);
    wp_enqueue_script('particles');

    // JS: Bootstrap
    wp_register_script('Bootstrap', RAYA_HHP_THEME_URI . 'assets/tmp/bootstrap.bundle.min.js', array(), RAYA_HHP_THEME_VERSION, true);
    wp_enqueue_script('Bootstrap');

    // JS: General
    wp_register_script('General_js', RAYA_HHP_THEME_URI . 'assets/js/general.js', array(), RAYA_HHP_THEME_VERSION, true);
    wp_enqueue_script('General_js');

    if (is_front_page()) {
        // JS: Index
        wp_register_script('Index_js', RAYA_HHP_THEME_URI . 'assets/js/isolated/index.js', array(), RAYA_HHP_THEME_VERSION, true);
        wp_enqueue_script('Index_js');
    }


    // WordPress Options:   .::::::::::::

    // Comment Reply
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'RAYA_HHP_enqueue_scripts');
