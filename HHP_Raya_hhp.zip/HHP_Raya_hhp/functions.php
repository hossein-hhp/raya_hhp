<?php
/*
* File Name:        functions.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

define('RAYA_HHP_THEME_VERSION', '1.0.0');
define('RAYA_HHP_THEME_DIR', trailingslashit(get_template_directory()));
define('RAYA_HHP_THEME_URI', trailingslashit(esc_url(get_template_directory_uri())));

// disable admin bar in frontend
show_admin_bar(false);


// Include Additional functions to the theme
require_once RAYA_HHP_THEME_DIR . 'functions/core/theme-setup.php';
require_once RAYA_HHP_THEME_DIR . 'functions/core/theme-enqueue-scripts.php';
require_once RAYA_HHP_THEME_DIR . 'functions/core/init-nav-widgets.php';
