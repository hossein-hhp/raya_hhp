<?php
/*
 * File Name:        header.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo("charset"); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" /> -->

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>