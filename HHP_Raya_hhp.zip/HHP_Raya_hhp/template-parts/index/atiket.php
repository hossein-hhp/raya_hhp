<?php
/*
 * File Name:        atiket.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<img src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/top_of_atiket_area.svg" id="top_of_atiket_area" alt="top of atiket area">

<section id="atiket_product">
    <div class="container-fluid">
        <h2 id="atiket_product_title" class="titles text-center">اتیکت اسم و فامیل پشت چسب‌دار مخصوص لوازم</h2>
            
        <p>آیا به دنبال راهی آسان و سریع برای نام‌گذاری منظم لوازم مدرسه فرزندتان با فونتی زیبا و شیک هستید؟ اتیکت اسم و فامیل پشت چسبدار ما، بهترین انتخاب برای شماست!
        <br/>
        <br/>
        این اتیکت‌ها از کاغذی ضخیم و با کیفیت ساخته شده‌اند و چاپ آن‌ها ماندگاری بالایی دارد، به‌طوری که تا چند سال تحصیلی مثل روز اول باقی می‌ماند. همچنین، پشت آن‌ها چسبی قوی دارد که برای مداد، خودکار و سایر لوازم مدرسه کاملاً مناسب است. هر برگه شامل ۱۵۰ عدد اتیکت است که برای چند سال تحصیلی کافی و بسیار مقرون‌به‌صرفه می‌باشد.</p>
        
        <!-- Swiper atiket -->
        <div class="swiper atiket">
            <img id="top_atiket_slider_holder" alt="top holder of atiket slider" src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/cover_of_atiket_slider.svg"/>
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img
                        src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/اتیکت نرجس.png" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/اتیکت نرجس.png" />
                </div>
                <div class="swiper-slide">
                    <img
                        src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/اتیکت نرجس.png" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/اتیکت نرجس.png" />
                </div>
            </div>
            <img id="bottom_atiket_slider_holder" alt="bottom holder of atiket slider" src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/cover_of_atiket_slider.svg"/>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
            <div class="autoplay-progress">
                <svg viewBox="0 0 48 48">
                    <circle cx="24" cy="24" r="20"></circle>
                </svg>
                <span></span>
            </div>
        </div>
    </div>
    
    <div id="attrbute_of_atiket" class="container">
        <h3 class="titles text-end">ویژگی‌های اتیکت اسم رایا</h3>
        
        <ul>
            <li>هر برگه شامل ۱۵۰ عدد اتیکت کاربردی و اقتصادی</li>
            <li>انتخاب نوع فونت، رنگ‌بندی‌ها (فونت و کادر دور) طبق سلیقه شما</li>
            <li>پشت چسبدار قوی و آسان برای چسباندن روی انواع وسایل</li>
            <li>کاغذ ضخیم و مقاوم</li>
            <li>چاپ با کیفیت و ماندگار</li>
            <li>مناسب برای مداد، خودکار و سایر لوازم تحصیلی</li>
        </ul>
    </div>
</section>

<img src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/bottom_of_atiket_area.svg" id="bottom_of_atiket_area" alt="bottom of atiket area">