<?php
/*
 * File Name:        shoaar_2.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<div id="shoaar_2">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/bottom_of_baner.svg" class="top_of_shoaar" alt="top_of_shoaar">
    <div class="heading">
        <h2>رضایت شما، اعتبار ماست</h2>
    </div>
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/bottom_of_baner.svg" class="bottom_of_shoaar" alt="bottom_of_shoaar">
</div>