<?php
/*
 * File Name:        first_baner.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="first_baner" class="container-fluid">
    <div id="particles-js">

        <div class="heading">
            <h2>ثبت سفارش و مشاهده نمونه کارهای ما:</h2>

            <div class="social_media_area">
                <a href="#" class="social_media">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/svg/telegram.svg"
                        alt="telegram-icon">
                    کانال تلگرام رایا
                </a>
                <a href="#" class="social_media">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/svg/instagram.svg"
                        alt="instagram-icon">
                    پیچ اینستاگرام رایا
                </a>
            </div>

        </div>

    </div>
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/page_parts/bottom_of_baner.svg" class="bottom_of_baner" alt="bottom of baner">
    <a href="#our_products" id="goto_down"></a>
</section>