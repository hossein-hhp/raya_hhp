<?php
/*
 * File Name:        barnameh_haftegi.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="barnameh_haftegi" class="container">

    <h2 class="titles text-center">برنامه هفتگی با شخصیت مورد علاقه</h2>
    
    <!-- TEST  -->
    <!--<div class="swiper-container main-swiper">-->
    <!--  <div class="swiper-wrapper">-->
    <!--    <div class="swiper-slide"><img src="https://s.uiinitiative.com/items/swiper-3d-pagination/screenshots/1.jpg" alt="Image 1" /></div>-->
    <!--    <div class="swiper-slide"><img src="https://s.uiinitiative.com/items/swiper-3d-pagination/screenshots/2.jpg" alt="Image 2" /></div>-->
    <!--    <div class="swiper-slide"><img src="https://s.uiinitiative.com/items/swiper-3d-pagination/screenshots/3.jpg" alt="Image 3" /></div>-->
    <!--  </div>-->
      <!-- اگر نیاز به pagination یا navigation دارید -->
    <!--  <div class="swiper-pagination"></div>-->
    <!--  <div class="swiper-button-next"></div>-->
    <!--  <div class="swiper-button-prev"></div>-->
    <!--</div>-->

    <!-- لایت‌باکس -->
    <div id="lightbox" class="lightbox">
      <div class="lightbox-swiper">
        <div class="swiper-wrapper">
          <!-- اسلایدهای لایت‌باکس به صورت داینامیک اضافه می‌شوند -->
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
      </div>
      <span id="lightbox-close" class="lightbox-close">&times;</span>
    </div>


    <p>بچه‌ها تا وقتی چیزی براشون جذاب نباشه، نه دلشون می‌خواد انجامش بدن و نه انگیزه‌ای برایش پیدا می‌کنند. حالا تصور کنید برنامه درسی هر روزشون با شوق و اشتیاق جمع بشه و هر لحظه براشون هیجان‌انگیز باشه!
با برنامه هفتگی ما، می‌تونید شخصیت‌های محبوب فرزندتون رو کنار عکس فرزند دلبندتون بیارین. شما با این برنامه هفتگی نه تنها نظم و برنامه‌ریزی رو به بچه‌ها هدیه می‌دید، بلکه روزهای شاد و پرانرژی براشون می‌سازید. 
<br/>
<br/>
هر روز با شخصیت دوست‌داشتنی‌شون برنامه‌ریزی کنن، کلی ذوق کنن و با انرژی به کارهاشون برسند! دیگه خبری از فراموشی و بی‌نظمی نیست، همه چیز مرتب و باحال پیش میره. یک دنیای رنگی و پر از هیجان که هر روزش پر از شادی و انگیزه‌ست، همینجاست! منتظر شماست!</p>


    <!-- Swiper barnameh haftegi -->
    <div id="barnameh_haftegi_slider" class="container">
        <div class="swiper largeSlide">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی آیناز حاتمی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی اصلی ماهان ایمانی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی امیرعلی طیبی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی مهدی ثروتی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی حدیث قلی پور.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی پرنیا.jpg" />
              </div>
                    <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی مهدی ثروتی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی حدیث قلی پور.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی پرنیا.jpg" />
              </div>
    
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <div thumbsSlider="" class="swiper thumbsSlider">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی آیناز حاتمی.jpg" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی اصلی ماهان ایمانی.jpg" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی امیرعلی طیبی.jpg" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی مهدی ثروتی.jpg" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی حدیث قلی پور.jpg" />
                </div>
                <div class="swiper-slide">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی پرنیا.jpg" />
                </div>
                      <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی مهدی ثروتی.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی حدیث قلی پور.jpg" />
              </div>
              <div class="swiper-slide">
                  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/برنامه هفتگی پرنیا.jpg" />
              </div>
                
            </div>
        </div>
        
        
        <div class="autoplay-progress">
            <svg viewBox="0 0 48 48">
                <circle cx="24" cy="24" r="20"></circle>
            </svg>
            <span></span>
        </div>
        
        
    </div>

    <div id="attrbute_of_barnameh_haftegi" class="container">
        <h3 class="titles text-end">ویژگی‌های برنامه هفتگی رایا</h3>
        
        <ul>
            <li>دو سایز کاربردی A4 و A5، مناسب برای استفاده در خانه و مدرسه</li>
            <li>کاغذ با ضخامت و کیفیت فوق‌العاده عالی برای ماندگاری بیشتر</li>
            <li>چاپ با کیفیت بالا برای جلوه‌ای زیبا و چشم‌نواز</li>
            <li>انتخاب بی‌نهایت شخصیت مورد علاقه فرزندتان از میان کارتون‌ها و انیمیشن‌های محبوب</li>
            <li>طراحی دقیق و مطابق با سلیقه شما برای برنامه‌ای کاملاً شخصی‌سازی شده</li>
        </ul>
    </div>
    
    <div id="recommendation_area">
        <p>
            با این برنامه هفتگی، فرزندتان هر روز با انگیزه و انرژی بیشتر به برنامه‌هایش می‌پردازد.
            <br/>
            همین امروز سفارش دهید و تفاوت را احساس کنید!
        </p>
    </div>
    
    
</section>