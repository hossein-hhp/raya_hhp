<?php
/*
 * File Name:        our_honors.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="our_honors">
    <div class="container text-center d-flex justify-content-between align-items-center">
        <div class="heading">
            <h2>افتخارات رایا</h2>
            <p>گواه تلاش و تعهد بی‌وقفه به رضایت  شما</p>
        </div>
        
        <div class="items">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/our_honors/wired-lineal-1780-medal-first-place-hover-pinch.gif" alt=""/>
            <div class="number">+8</div>
            <div class="details">سال سابقه فعالیت</div>
        </div>
        
        <div class="items">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/our_honors/wired-lineal-153-bar-chart-hover-pinch.gif" alt=""/>
            <div class="number">+2000</div>
            <div class="details">محصول فروخته شده</div>
        </div>
        
        <div class="items">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/our_honors/wired-flat-1865-shooting-stars-hover-pinch.gif" alt=""/>
            <div class="number">98%</div>
            <div class="details">رضایت مشتری از محصول</div>
        </div>
            
    </div>
</section>