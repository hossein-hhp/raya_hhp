<?php
/*
 * File Name:        our_products.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="our_products" class="container">

    <h2 class="titles text-center">محصولات رایا:</h2>

    <div class="products">
        <div class="product">
            <h3>برچسب اسم</h3>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg"
                alt="نمونه کار برچسب اسم رایا">
        </div>
        <div class="product">
            <h3>برنامه هفتگی</h3>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برنامه هفتگی پرنیا.jpg"
                alt="نمونه کار برنامه هفتگی رایا">
        </div>
        <div class="product">
            <h3>اتیکت اسم</h3>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/اتیکت نرجس.png"
                alt="نمونه کار اتیکت اسم رایا">
        </div>
    </div>

</section>