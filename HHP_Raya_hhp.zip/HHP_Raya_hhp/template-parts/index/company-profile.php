<?php
/*
* File Name:        footer.php
* Author:           Sohrab Yazdanparast <sohrab.yazdan@yahoo.com>
* License:          Check license URI for more information
* @Author-URI:      https://www.www.venus-itc.com.com
* @Version:         1.0.0
* @License-URI:     https://www.venus-itc.com/license
*/
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section class="company-profile">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-11">
                <div class="company-profile__wrapper">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="company-profile__inner">
                                <h3 class="company-profile__title">
                                    Company Profile
                                </h3>
                                <div class="company-profile__details">
                                    Matn Pish Farz Ast, MFS is a reliable, established company that designs and manufactures process and mechanical equipment as well as various process packages. MFS also offers EPC engineering services for oil, gas, petrochemical, power & utility sectors. Currently active in strategic oil-producing regions like Iran,
                                </div>
                                <div class="company-profile__slider">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>