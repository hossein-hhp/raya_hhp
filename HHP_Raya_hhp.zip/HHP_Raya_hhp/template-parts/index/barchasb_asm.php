<?php
/*
 * File Name:        barchasb_asm.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="barchasb_asm" class="container">

    <h2 class="titles text-center">برچسب اسم با شخصیت مورد علاقه</h2>

    <p>بیایید لحظاتی را تصور کنیم که ببینید فرزند دلبندتان چطور لبخند می‌زند و شاد می‌شود وقتی خودش را با شخصیت‌های مورد
    علاقه‌اش روی دفتر و کتاب مدرسه‌اش می‌بیند. لحظاتی را حس کنید که فرزند دلبندتان، تجربه خاص بودن و منحصربه‌فرد بودن را بین همکلاسی‌هایش تجربه می‌کند. این لحظه‌ها، هدیه‌ای ویژه به فرزندانتان خواهد بود و خاطراتی ناب و فراموش‌نشدنی ایجاد می‌کند.
    </p>


    
<!--
            بررسی بشه جاوا اسکریپت جایی ازش استفاده شده یا نه
            
    <div id="barchasb_asm-slider">
        <div class="barchasb_asm-slides">
            <img src="<?php // echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg"
                alt="نمونه کار برچسب اسم رایا">
        </div>
        <div class="barchasb_asm-slides">
            <img src="<?php // echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg"
                alt="نمونه کار برچسب اسم رایا">
        </div>
        <div class="barchasb_asm-slides">
            <img src="<?php // echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg"
                alt="نمونه کار برچسب اسم رایا">
        </div>
        <div class="barchasb_asm-slides">
            <img src="<?php // echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg"
                alt="نمونه کار برچسب اسم رایا">
        </div>
    </div> 
-->



    <!-- Swiper barchasb asm -->
    <div class="swiper barchasb_asm_Swiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب غزل آزاد.jpg" />
            </div>
            <div class="swiper-slide">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب غزل آزاد.jpg" />
            </div>
            <div class="swiper-slide">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب غزل آزاد.jpg" />
            </div>
            <div class="swiper-slide">
                <img
                    src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب حسین نیک نام (2).jpg" />
            </div>
            <div class="swiper-slide">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/products/resized/برچسب غزل آزاد.jpg" />
            </div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
        <div class="autoplay-progress">
            <svg viewBox="0 0 48 48">
                <circle cx="24" cy="24" r="20"></circle>
            </svg>
            <span></span>
        </div>
    </div>
    

    <div id="attrbute_of_barchasb_asm" class="container">
        <h3 class="titles text-end">ویژگی‌های برچسب اسم رایا</h3>
        
        <ul>
            <li>هر برگه شامل 15 عدد برچسب</li>
            <li>انتخاب بی‌نهایت شخصیت مورد علاقه</li>
            <li>مناسب بر ای دفتر کتاب، دفتر، دفترچه یادداشت و...</li>
            <li>پشت چسب دار برای استفاده آسان</li>
            <li>کاغذ با ضخامت و کیفیت فوق العاده عالی برای ماندگاری بیشتر</li>
            <li>چاپ با کیفیت برای جلوه بیشتر</li>
            <li>طراحی دقیق و مطابق با سلیقه شما</li>
        </ul>
    </div>
    
</section>