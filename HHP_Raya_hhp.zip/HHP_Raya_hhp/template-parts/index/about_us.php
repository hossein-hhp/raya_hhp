<?php
/*
 * File Name:        about_us.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<section id="about_us">
    <div class="container">
        
        <div class="row flex-row-reverse">
            
            <div class="col-4">
                <img id="image_of_about_us" src="<?php echo get_template_directory_uri(); ?>/assets/img/about_us/aboutUs image.svg" class="" alt="">
            </div>
            
            <div class="col">
            
                <h2 id="title_of_about_us">درباره رایا</h2>
                <p class="titles">چرا رایا بهترین انتخاب من برای سفارش هستش؟!</p>
                <p id="subtitle_of_about_us">سفارش شما فقط یک خرید نیست، بلکه شروع یک خاطره شیرین است.</p>
                <p class="texts">ما با تمرکز بر سلیقه شما، طراحی و چاپ محصولات را با بالاترین کیفیت و دقت  انجام می‌دهیم تا بهترین رنگ‌بندی و جلوه را برای شما و فرزند دلبندتان به ارمغان بیاوریم.</p>
            </div>
            

        </div>
        
    </div>
</section>