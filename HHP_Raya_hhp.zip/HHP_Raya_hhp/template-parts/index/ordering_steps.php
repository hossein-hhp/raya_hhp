<?php
/*
 * File Name:        ordering_steps.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<section id="ordering_steps" class="container">
    
    <h2 class="titles text-center">راهنمایی از سفارش تا تحویل ...</h2>

    <div id="main_steps" class="container">
        
        <!--<img id="line_starter" src="<?php //echo get_template_directory_uri(); ?>/assets/img/ordering_steps/Line 0.svg" />-->
        
        <div class="steps text-white">
            <div class="img_area">
                <!-- عکسش باید تغییر کنه-->
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-981-consultation-hover-conversation 1.gif" />
            </div>
            <div class="number">1</div>
            <h3 class="title_of_step">ارتباط</h3>
            <div class="links">
                <a href="#?">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/telegram_of_step.gif" />
                </a>
                <a href="#?">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/instagram_of_step.gif" />
                </a>
            </div>
            <p class="description">از طریق شبکه‌های اجتماعی  و یا شماره تماس ارتباط برقرار می‌شود.</p>
        </div>
        
        <div class="steps">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-146-trolley-hover-jump(1).gif" />
            </div>
            <div class="number">2</div>
            <h3 class="title_of_step">انتخاب محصولات</h3>
            <p class="description">انتخاب محصولات مدنظر از میان محصولات رایا (برچسب اسم، برنامه هفتگی، اتیکت اسم)</p>
        </div>
        
        <div class="steps">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-3098-picture-letter-hover-pinch.gif" />
            </div>
            <div class="number">3</div>
            <h3 class="title_of_step">ارسال  اطلاعات</h3>
            <p class="description">ارسال عکس، اسم و فامیلی و مشخص شدن شخصیت مورد علاقه مشتری</p>
        </div>
        
        <div class="steps">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-37-approve-checked-simple-hover-wobble.gif" />
            </div>
            <div class="number">4</div>
            <h3 class="title_of_step">بررسی کیفیت</h3>
            <p class="description">کاشناسان رایا برای هرچه زیبا تر شدن  کار نهایی، کیفیت عکس ارسالی را بررسی و تایید می‌کنند.</p>
        </div>
        
        <div class="steps">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-flat-948-stock-share-hover-pinch(1).gif" />
            </div>
            <div class="number">5</div>
            <h3 class="title_of_step">محاسبه صورتحساب</h3>
            <p class="description">صورتحساب برای مشتری ارسال می‌شود و نحوه پرداخت تعیین  می‌گردد.</p>
        </div>
        
        <div class="steps text-white">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-35-edit-hover-circle.gif" />
            </div>
            <div class="number">6</div>
            <h3 class="title_of_step">طراحی سفارشات</h3>
            <p class="description">با تعامل کامل و دقیقا طبق سلیقه مشتری سفارشات طراحی و توسط مشتری تایید می‌شود.</p>
        </div>
        
        <div class="steps text-white">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-54-photo-morph-portrait.gif" />
            </div>
            <div class="number">7</div>
            <h3 class="title_of_step">چاپ سفارشات</h3>
            <p class="description">پس اینکه مشتری طرح‌ها را برای چاپ تایید کرد، سفارشات با بهترین کیفیت چاپ می‌شود.</p>
        </div>
        
        <div class="steps">
            <div class="img_area">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ordering_steps/wired-lineal-177-envelope-send-hover-flying.gif" />
            </div>
            <div class="number">8</div>
            <h3 class="title_of_step">ارسال سفاشات</h3>
            <p class="description">محل دریافت سفارش توسط مشتری مشخص شده و سفارشات ارسال می‌شود.</p>
        </div>

        
        
    </div>
    
    <div class="titles text-center">... برای لبخند شادی فرزندتان</div>

</section>