<?php
/*
 * File Name:        contact_us.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<section id="contact_us">
    <div class="container">
        
        <div class="row">
            
            <div class="col-5">
                <img id="image_of_contact_us" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/contact_us.svg" class="" alt="">
            </div>
            
            <div class="col">
            
                <h2 id="title_of_contact_us">ارتباط با رایا</h2>
                <p class="titles">می‌خوام سفارش بدم، حالا از کجا شروع کنم؟!</p>
                <p id="subtitle_of_contact_us">ما همیشه آماده پاسخگویی به شما هستیم.</p>
                <p class="texts">همین حالا از طریق <span class="primary-color">تلگرام</span> یا <span class="pink-color">اینستاگرام</span> با رایا در ارتباط باشید!  نمونه کارهای ما را ببینید، سفارش خود را ثبت کنید و هر سوالی که دارید در ۲۴ ساعت شبانه‌روز از ما بپرسید.</p>
                
                <div class="row linkArea">
                    
                    <a class="col-5 links_contact_us" href="#">
                        <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/telegram.svg" alt="">
                        <div class="linkTitle">@Raya_hhp</div>
                    </a>
                    
                    <a class="col-5 links_contact_us" href="#">
                        <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/instagram.svg" alt="">
                        <div class="linkTitle">Raya_hhp</div>
                    </a>
                    
                    <a class="col-5 links_contact_us" href="#">
                        <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/whatsUp.svg" alt="">
                        <div class="linkTitle">0905 81 504 85</div>
                    </a>
                    
                    <a class="col-5 links_contact_us" href="#">
                        <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/phone-call-mobile-phone-svgrepo-com(1) 1.svg" alt="">
                        <div class="linkTitle">0905 81 504 85</div>
                    </a>
                    
                </div>
                
            </div>
            

        </div>
        
    </div>
</section>