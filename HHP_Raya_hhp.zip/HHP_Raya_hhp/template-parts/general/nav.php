<?php
/*
 * File Name:        nav.php
 * Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
 * License:          Check license URI for more information
 * @Author-URI:      -
 * @Version:         1.0.0
 * @License-URI:     --
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<nav id="top_menu_disktop" class="w-100">
    <div id="top_menu_disktop" class="container d-flex align-items-center justify-content-around">
        <img id="logo_raya" alt="logo raya_hhp"
            src="<?php echo get_template_directory_uri(); ?>/assets/img/logo_raya.png" />
        <ul>
            <li class="our_products">
                <a href="#our_products">محصولات رایا</a>
            </li>
            <li class="barchasb_asm">
                <a href="#barchasb_asm">برچسب اسم</a>
            </li>
            <li class="atiket_product">
                <a href="#atiket_product_title">اتیکت اسم</a>
            </li>
            <li class="barnameh_haftegi">
                <a href="#barnameh_haftegi">برنامه هفتگی</a>
            </li>
            <li class="ordering_steps">
                <a href="#ordering_steps">مراحل سفارش</a>
            </li>
            <li class="contact_us">
                <a href="#contact_us">ارتباط با رایا</a>
            </li>
            <li class="about_us">
                <a href="#about_us">درباره رایا</a>
            </li>
        </ul>
    </div>
</nav>