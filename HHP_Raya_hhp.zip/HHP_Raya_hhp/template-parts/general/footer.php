<?php
/*
* File Name:        footer.php
* Author:           Hossein Hosseinpour <hossein.hhp.2@gmail.com>
* License:          Check license URI for more information
* @Author-URI:      -
* @Version:         1.0.0
* @License-URI:     --
*/
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<footer id="general-footer">

    <div class="footer-section-wrapper row">
        <div class="footer-sides col-6">
            
            <h4 class="footer-title">چرا طراحی و چاپ رایا </h4>
            <p class="footer-content row">رایا، فروشگاه اینترنتی معتبر از سال ۱۳۹۶، همون جایی هستش که سفارش‌هاتون تبدیل میشه به یه خاطره شیرین و خاص! ما با دقت و عشق، سفارش‌ها رو دقیقاً طبق سلیقه شما طراحی و چاپ می‌کنیم و همیشه تلاش می‌کنیم تا بهترین کیفیت رو با مناسب‌ترین قیمت و در کوتاه‌ترین زمان به دستتون برسونیم. با رایا، تجربه خریدی متفاوت و دوست‌داشتنی داشته باشید!
            </p>
        </div>
        
        <div class="footer-sides col-6">
            
            <h4 class="footer-title">راه‌های ارتباطی</h4>
            <div class="footer-content row">
                <a href="#" class="footer-links co-12">
                    <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/telegram.svg" alt="Telegram Icon">
                    <div class="linkTitle">@Raya_hhp</div>
                </a>
                <a href="#" class="footer-links co-12">
                    <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/phone-call-mobile-phone-svgrepo-com(1) 1.svg" alt="Phone Icon">
                <div class="linkTitle">0905 81 504 85</div>
                </a>
                <a href="#" class="footer-links co-12">
                    <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/instagram.svg" alt="Instagram Icon">
                    <div class="linkTitle">Raya_hhp</div>
                </a>
                <a href="#" class="footer-links co-12">
                    <img class="linkImage" src="<?php echo get_template_directory_uri(); ?>/assets/img/contact_us/whatsUp.svg" alt="WhatsApp Icon">
                    <div class="linkTitle">0905 81 504 85</div>
                </a>
            </div>


        </div>
        
        <div class="website-author col-6 mt-4">
            <p class="footer-content">
                طراحی و توسعه یافته توسط: 
                حسین حسین‌پور
            </p>
        </div>
        
        <div class="footer-copywrite col-6 mt-4">
            تمام حقوق برای رایا محفوظ است. © 2017-2025
        </div>
    </div>

</footer>